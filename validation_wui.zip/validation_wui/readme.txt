# File Descriptions:

# "coord.X","coord.Y" 
--> coordinated in respective projection system (see below)
Adelaide (Australia) - EPGS 32354
Cape Town (South Africa) - EPSG 32734
Lisbon (Portugal) - EPGS 32629
San Diego (California) - EPGS 32611
Santiago (Chile) - EPGS 32719


# "WUI_LABEL"
non-WUI = 
ix_woody = intermix WUI with woody vegetation
if_woody = interface WUI with woody vegetation
ix_non_woody = intermix WUI with non-woody vegetation
if_non_woody = interface WUI with non-woody vegetation


# "WUI_NUM"
0 = non-wui
1 = intermix WUI with woody vegetation
2 = interface WUI with woody vegetation
3 = intermix WUI with non-woody vegetation
4 = interface WUI with non-woody vegetation


# "WUI_binary_2000","WUI_binary_2020"
0 = non-WUI
1 = WUI


# "WUI_CHANGE"
# 0 = stable NON-WUI
# 1 = stable WUI
# 2 = WUI growth
# 3 = WUI loss


# "Reference_image_year_for_2000","Reference_image_year_for_2020"
Avalibale Reference images that was used for the valiation in Google Earth Pro
