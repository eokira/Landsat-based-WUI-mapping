# Statistical Metrics:

Q10 = 10th quantile 
Q20 = 20th quantile 
Q25 = 25th quantile 
Q50 = 50th quantile 
Q75 = 75th quantile 
Q80 = 80th quantile 
Q90 = 90th quantile 
MAX = Maximum
MIN = Minimum
AVG = Average
RNG = Range
IQR = Interquartile Range
SKW = Skewness


# Band names:

BLU = Blue Band
GRN = Green Band
RED = Red Band
NIR = Near Infrared Band
SW1 = SWIR 1 Band
SW2 = SWIR 2 Band
TCG = Tasseled Cap Greenness
EVI = Enhanced Vegetation Index
Blusw1 = Visible Blue Shortwave Infrared Built-up Index 
BCI = Biophysical Composition Index 
copernicusDEM = Copernicus DEM 


# Land Cover Classes:

1 = water
2 = bare surfaces (soil, rocks, sand, ...)
3 = impervious (buildings, roads, human-made surfaces)
4 = woody vegetation
5 = non-woody vegetation


# Coordinated in respective projection system (see below):

Adelaide (Australia) - EPGS 32354
Cape Town (South Africa) - EPSG 32734
Lisbon (Portugal) - EPGS 32629
San Diego (California) - EPGS 32611
Santiago (Chile) - EPGS 32719

