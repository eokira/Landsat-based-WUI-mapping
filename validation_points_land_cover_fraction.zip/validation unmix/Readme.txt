# file description:



"X","Y" --> coordinated in respective projection system (see below)

Adelaide (Australia) - EPGS 32354
Cape Town (South Africa) - EPSG 32734
Lisbon (Portugal) - EPGS 32629
San Diego (California) - EPGS 32611
Santiago (Chile) - EPGS 32719



"landcover" --> number that represents land cover class

1 = water
2 = bare surfaces (soil, rocks, sand, ...)
3 = imperviousness (buildings)
4 = woody vegetation
5 = non-woody vegetation
6 = imperviousness (non-buildings)